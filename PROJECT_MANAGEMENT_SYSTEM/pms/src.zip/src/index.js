import { React, StrictMode } from 'react';
import ReactDOM from 'react-dom/client';
import App from './pageJSX/App';
import reportWebVitals from './reportWebVitals';
import { DarkModeProvider } from './pageJSX/DarkModeProvider';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <StrictMode>
    <DarkModeProvider>
      <App />
    </DarkModeProvider>
  </StrictMode>
);

reportWebVitals();

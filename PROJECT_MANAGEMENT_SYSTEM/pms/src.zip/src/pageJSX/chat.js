import React, { useState, useRef } from 'react';
import '../css/chat.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPaperPlane } from '@fortawesome/free-solid-svg-icons';
// import socketIOClient from 'socket.io-client';

const Chat = ({ username }) => {
    const [isChatOpen, setIsChatOpen] = useState(false);

    const toggleChat = () => {
        setIsChatOpen(!isChatOpen);
    };
    const [messages, setMessages] = useState([
        { id: 1, sender: 'John', content: 'Hello!' },
        { id: 2, sender: 'Jane', content: 'Hi there!' },
        { id: 3, sender: 'John', content: 'How are you?' },
    ]);
    const [newMessage, setNewMessage] = useState('');
    const messagesRef = useRef(null);

    // useEffect(() => {
    //   const socket = socketIOClient('<your-backend-chat-server-url>');

    //   // Fetch existing chat messages
    //   socket.on('connect', () => {
    //     socket.emit('fetchMessages');
    //   });

    //   // Receive chat messages
    //   socket.on('message', (message) => {
    //     setMessages((prevMessages) => [...prevMessages, message]);
    //   });

    //   return () => {
    //     socket.disconnect();
    //   };
    // }, []);

    const handleSendMessage = (e) => {
        e.preventDefault();

        // Trim the spaces at the beginning and end of the message
        const trimmedMessage = newMessage.trim();

        // Send message to the chat server
        // socket.emit('sendMessage', trimmedMessage);

        if (trimmedMessage !== '') {
            const newMessageObj = {
                id: messages.length + 1,
                sender: username,
                content: trimmedMessage,
            };

            setMessages((prevMessages) => [...prevMessages, newMessageObj]);
            setNewMessage('');

            // Scroll to the latest message
            setTimeout(() => {
                if (messagesRef.current) {
                    const messagesContainer = messagesRef.current;
                    const lastMessage = messagesContainer.lastElementChild;
                    lastMessage.scrollIntoView({ behavior: 'smooth' });
                }
            }, 10);
        }
    };



    const sendMessage = (value) => {
        setNewMessage(value);
    };

    return (
        <div className={`chat-container ${isChatOpen ? 'open' : ''}`}>
            {isChatOpen ? (
                <div className="chat-window">
                    <div className="chat-header">
                        <h2>Team Chat</h2>
                        <button onClick={toggleChat}>&times;</button>
                    </div>
                    <div className="chat-messages" ref={messagesRef}>
                        {messages.map((message) => (
                            <div
                                key={message.id}
                                className={`message ${message.sender === username ? 'sent user1' : 'received user2'
                                    }`}
                            >
                                <span>{message.sender !== username && message.sender + ":"}  </span>
                                <span>{message.content}</span>
                            </div>
                        ))}
                    </div>
                    <form className="chat-form" onSubmit={handleSendMessage}>
                        <div className="send-area">
                            <input
                                type="text"
                                placeholder="Type your message..."
                                value={newMessage}
                                onChange={(e) => sendMessage(e.target.value)}
                            />


                            <button type='submit' className='button'>
                                <FontAwesomeIcon icon={faPaperPlane} />
                            </button>
                        </div>
                    </form>
                </div>
            ) : (
                <div className="chat-toggle-button" onClick={toggleChat}>
                    Chat with Team
                </div>
            )}
        </div>
    );
};

export default Chat;
import React, { useState, useContext, useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import '../css/ProjectWorkArea.css';
import SideBar from './SideBar';
import { DarkModeContext } from './DarkModeProvider';
import '../css/Mode.css';
import TopBar from './TopBar';
import { clearTokenAndUserName } from './AuthStorageUtil';
import ProfileSlider from './ProfileSlider';
import BacklogArea from './BacklogArea';
import MembersPage from './MembersPage';

const ProjectWorkArea = () => {
    const { mode, toggleMode } = useContext(DarkModeContext);
    const [SliderisOpen, setSliderIsOpen] = useState(false);
    const history = useHistory();
    const [view, setView] = useState('backlog');


    useEffect(() => {
        const savedView = localStorage.getItem('lastSelectedView');
        if (savedView) {
            setView(savedView);
        }
    }, []);

    function setUpView(view) {
        setView(view);
        // Save the selected view to localStorage
        localStorage.setItem('lastSelectedView', view);
    }

    const toggleSlider = () => {
        setSliderIsOpen(!SliderisOpen);
    };

    const LogOut = () => {
        clearTokenAndUserName();
        history.push('/auth');
    }



    return (
        <div className={mode === 'dark' ? 'dark' : ''}>
            <TopBar
                mode={mode}
                toggleMode={toggleMode}
                toggleSlider={toggleSlider}
            />
            <div>
                {view === 'backlog' && (
                    <div className='backLogArea'>
                        <BacklogArea
                            setUpView={setUpView}
                            view={view}
                        />
                    </div>
                )}

                {view === 'team' && (
                    <div className='MembersArea'>
                        <MembersPage
                            setUpView={setUpView}
                            view={view}
                        />
                    </div>
                )}
                {
                    SliderisOpen && (
                        <ProfileSlider
                            SliderisOpen={SliderisOpen}
                            LogOut={LogOut}
                            setSliderIsOpen={setSliderIsOpen}
                        />
                    )
                }
            </div>
        </div>
    );
};

export default ProjectWorkArea;
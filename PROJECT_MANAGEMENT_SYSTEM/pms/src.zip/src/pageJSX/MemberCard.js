import React from 'react';

const MemberCard = ({ member }) => {
    return (
        <div className="member-card">
            <div className="member-info">
                <img src={member.avatar} alt="Member Avatar" className="avatar" />
                <h4 className="member-name">{member.name}</h4>
                <p className="member-role">{member.role}</p>
            </div>
        </div>
    );
};

export default MemberCard;

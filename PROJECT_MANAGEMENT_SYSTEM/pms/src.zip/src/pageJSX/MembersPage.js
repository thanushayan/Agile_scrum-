import React, { useState, useEffect, useContext } from 'react';
import '../css/MembersPage.css';
import axios from 'axios';
import config from '../config.json';
import { useParams } from 'react-router-dom';
import { getItemFromLocalStorage } from './AuthStorageUtil';
import { DarkModeContext } from './DarkModeProvider';
import { FaSun, FaMoon, FaPlus } from 'react-icons/fa';
import MemberCard from './MemberCard.js';
import Sidebar from './SideBar';
import Chat from './chat';

const MembersPage = ({ view, setUpView }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [members, setMembers] = useState([
        { id: 1, name: 'John Doe', role: 'Developer' },
        { id: 2, name: 'Jane Smith', role: 'Designer' },
        { id: 3, name: 'Mark Johnson', role: 'Tester' },
        { id: 3, name: 'Mark Johnson', role: 'Tester' },
        { id: 3, name: 'Mark Johnson', role: 'Tester' },
        { id: 3, name: 'Mark Johnson', role: 'Tester' },
        { id: 3, name: 'Mark Johnson', role: 'Tester' },

        // Add more members as needed
    ]);

    const { projectId } = useParams();
    const { mode, toggleMode } = useContext(DarkModeContext);

    const OpenAddMemberPopup = () => {
        setIsOpen(true);
    };

    const closeAddMemberPopup = () => {
        setIsOpen(false);
    };

    const ServerURL = config.APIURL;
    const TOKEN = getItemFromLocalStorage('token');
    const username = getItemFromLocalStorage('username');

    useEffect(() => {
        fetchMembers();
    }, []);

    const fetchMembers = async () => {
        try {
            const response = await axios.get(`${ServerURL}api/project-and-user/get-users/${projectId}`, {
                headers: {
                    Authorization: TOKEN,
                },
            });
            if (Array.isArray(response.data)) {
                setMembers(response.data);
            } else {
                console.error('Invalid response format: Expected an array of members');
            }
        } catch (error) {
            if (error.response) {
                console.error('Error fetching members:', error.response.data);
                console.error('Status code:', error.response.status);
            } else if (error.request) {
                console.error('Error fetching members: No response received');
            } else {
                console.error('Error fetching members:', error.message);
            }
        }
    };


    const addMember = (e) => {
        e.preventDefault();

        const formData = new FormData(e.target);
        const userID = formData.get('id');

        const requestBody = {
            projectId: projectId,
            userId: userID,
            userRole: 'Member',
        };

        axios
            .post(`${ServerURL}api/project-and-user/add`, requestBody, {
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: TOKEN,
                },
            })
            .then((response) => {
                if (response.status === 200) {
                    // Member added successfully
                    console.log('Member added successfully');
                    // Perform any additional actions, such as updating state or displaying a success message
                    fetchMembers(); // Fetch the updated list of members
                    closeAddMemberPopup(); // Close the add member popup
                } else {
                    // Error adding member
                    console.log('Error adding member');
                    // Handle the error as needed
                }
            })
            .catch((error) => {
                console.log('API call error:', error);
                // Handle any errors that occurred during the API call
            });
    };

    return (
        <div className={mode === 'dark' ? 'dark' : ''}>
            <div className="top-bar">
                <div className="toggle-case" onClick={toggleMode}>
                    <div onClick={toggleMode} className="toggle">{mode === 'dark' ? <FaMoon /> : <FaSun />}</div>
                </div>
                <button className="profile-button" onClick={OpenAddMemberPopup}>Profile</button>
            </div>
            <div className="members-page">
                <Sidebar
                    setUpView={setUpView}
                    view={view}
                />

                <div className="members-container">
                    <div className="members-header">
                        <h2>Team Members</h2>
                        <button className="add-member-button" onClick={OpenAddMemberPopup}>
                            <FaPlus /> Add Member
                        </button>
                    </div>

                    <div className="members-list">
                        {members.map((member) => (
                            <MemberCard key={member.userId} member={member} />
                        ))}
                    </div>
                </div>
                <Chat
                    username={username}
                />
                {isOpen && (
                    <div className="add-member-popup">
                        <div className="add-member-popup-content">
                            <h3>Add Member</h3>
                            <form onSubmit={addMember} className="add-member-form">
                                <input type="text" name="id" placeholder="Enter ID" />
                                <div className="buttons-pop">
                                    <button className="cancel-button" onClick={closeAddMemberPopup}>Cancel</button>
                                    <button type="submit" className="Add-button">Add</button>
                                </div>
                            </form>
                        </div>
                    </div>
                )}

            </div>
            <div className='chat-area'>

            </div>
        </div>
    );
};

export default MembersPage;




import React, { useState, useEffect, useRef, useContext } from 'react';
import { useParams, useHistory } from 'react-router-dom';
import { FaCheck, FaChevronDown, FaChevronRight, FaEdit, FaTrashAlt, FaPlay } from 'react-icons/fa';
import config from '../config.json';
import { getItemFromLocalStorage } from './AuthStorageUtil';
import axios from 'axios';
import DeleteSprint from './DeleteSprint';
import Sidebar from './SideBar';


const BacklogArea = ({ view, setUpView }) => {
    const [backlogs, setBacklogs] = useState([]);
    const [sprints, setSprints] = useState([]);
    const [newBacklog, setNewBacklog] = useState('');
    const { projectId } = useParams();
    const [showAddTaskInput, setShowAddTaskInput] = useState(false);
    const [showAddSubtaskInput, setShowAddSubtaskInput] = useState(null);
    const [showExpandSprint, setShowSprintExpand] = useState(null);
    const [showExpandTask, setShowTaskExpand] = useState(null);
    const subtaskInputRef = useRef(null);
    const sprintTableRef = useRef(null);
    const [Sprintexpand, setSprintExpand] = useState(false);
    const [Taskexpand, setTaskExpand] = useState(false);
    const [selectedTaskId, setselectedTaskId] = useState(false);
    const [selectedSprintId, setSelectedSprintId] = useState(null);
    const [isOpenDelConfirm, setIsOpenDelConfirm] = useState(false);
    const history = useHistory();

    useEffect(() => {
        fetchSprints(); // Fetch the list of sprints when the component mounts
    }, []);


    const ServerURL = config.APIURL;
    const TOKEN = getItemFromLocalStorage('token');
    const username = getItemFromLocalStorage('username');

    const fetchSprints = async () => {
        try {
            const response = await axios.get(`${ServerURL}sprints/get/${username} /${projectId}`, {
                headers: {
                    Authorization: TOKEN,
                },
            });
            setSprints(response.data);
        } catch (error) {
            if (error.response) {
                // The request was made and the server responded with a status code outside the range of 2xx
                console.error('Error fetching sprints:', error.response.data);
                console.error('Status code:', error.response.status);
            } else if (error.request) {
                // The request was made but no response was received
                console.error('Error fetching sprints: No response received');
            } else {
                // Something happened in setting up the request that triggered an error
                console.error('Error fetching sprints:', error.message);
            }
        }
    };



    const handleBacklogChange = (e) => {
        setNewBacklog(e.target.value);
    };

    const handleAddBacklog = () => {
        if (newBacklog) {
            setBacklogs([...backlogs, newBacklog]);
            setNewBacklog('');
        }
    };

    const handleStartSprint = (sprintId) => {
        setSelectedSprintId(sprintId);
    };

    const handleBlurSprint = () => {
        setSelectedSprintId(null);
    };

    const handleAddSprint = async () => {
        const sprintNumber = sprints.length + 1;
        try {
            const sprint = {
                name: 'Sprint :' + `${sprintNumber}`,
                description: null,
                creatorId: `${username}`,
                startDate: null,
                endDate: null,
            };

            const response = await axios.post(
                `${ServerURL}sprints/create-sprint/${username}/add/${projectId}`,
                sprint,
                {
                    headers: {
                        'Content-Type': 'application/json',
                        Authorization: TOKEN,
                    },
                }
            );
            fetchSprints(); // Fetch the updated list of sprints
        } catch (error) {
            if (error.response) {
                // The request was made and the server responded with a status code outside the range of 2xx
                console.error('Error adding sprint:', error.response.data);
                console.error('Status code:', error.response.status);
            } else if (error.request) {
                // The request was made but no response was received
                console.error('Error adding sprint: No response received');
            } else {
                // Something happened in setting up the request that triggered an error
                console.error('Error adding sprint:', error.message);
            }
        }
    };



    const handleAddTaskToSprint = async (task, sprintIndex) => {
        setShowAddTaskInput(false); // Reset the state after adding the task

        try {
            const sprintId = sprints[sprintIndex].sprintId;
            const newTask = {
                title: task,
                description: null,
                createdBy: username,
                assignedTo: null,
            };

            const response = await axios.post(
                `${ServerURL}tasks/create-task/s/${sprintId}`,
                newTask,
                {
                    headers: {
                        'Content-Type': 'application/json',
                        Authorization: TOKEN,
                    },
                }
            );

            const updatedSprints = [...sprints];
            updatedSprints[sprintIndex].tasks.push(response.data);
            setSprints(updatedSprints);
        } catch (error) {
            // Handle error
            console.error('Error adding task:', error.message);
        }
    };


    const handleAddSubtaskToTask = (subtask, sprintIndex, taskIndex) => {
        const updatedSprints = [...sprints];
        updatedSprints[sprintIndex].tasks[taskIndex].subtasks.push(subtask);
        setSprints(updatedSprints);
    };

    const handleDragStart = (e, title, sourceType, sprintIndex, taskIndex, backlogIndex) => {
        e.dataTransfer.setData(
            'text/plain',
            JSON.stringify({ title, sourceType, sprintIndex, taskIndex, backlogIndex })
        );
    };

    const handleDrop = (e, targetType, targetSprintIndex, targetTaskIndex) => {
        e.preventDefault();
        const sourceData = JSON.parse(e.dataTransfer.getData('text/plain'));
        const title = sourceData.title
        const sourceType = sourceData.sourceType;
        const sourceSprintIndex = sourceData.sprintIndex;
        const sourceTaskIndex = sourceData.taskIndex;
        const sourceBacklogIndex = sourceData.backlogIndex;

        if (targetType === 'sprint') {
            if (sourceType === 'sprint') {
                // Move task within the same sprint
                if (sourceSprintIndex === targetSprintIndex) {
                    const updatedSprints = [...sprints];
                    const tasks = updatedSprints[sourceSprintIndex].tasks;
                    const [removed] = tasks.splice(sourceTaskIndex, 1);
                    tasks.splice(targetTaskIndex, 0, removed);
                    setSprints(updatedSprints);
                } else {
                    const updatedSprints = [...sprints];
                    const sourceTasks = updatedSprints[sourceSprintIndex].tasks;
                    const targetTasks = updatedSprints[targetSprintIndex].tasks;
                    const [removed] = sourceTasks.splice(sourceTaskIndex, 1);
                    targetTasks.splice(targetTaskIndex, 0, removed);
                    setSprints(updatedSprints);
                }
            } else if (sourceType === 'backlog') {
                // Move backlog to a sprint
                const updatedSprints = [...sprints];
                const task = { title: backlogs[sourceBacklogIndex].title, subtasks: [] };
                updatedSprints[targetSprintIndex].tasks.splice(targetTaskIndex, 0, task);
                setSprints(updatedSprints);
                setBacklogs(backlogs.filter((_, index) => index !== sourceBacklogIndex));
            }
        } else if (targetType === 'backlog') {
            if (sourceType === 'sprint') {
                // Move task to backlog
                const updatedSprints = [...sprints];
                const task = updatedSprints[sourceSprintIndex].tasks[sourceTaskIndex];
                updatedSprints[sourceSprintIndex].tasks.splice(sourceTaskIndex, 1);
                setSprints(updatedSprints);
                setBacklogs([...backlogs, task]);
            }
        } else if (sourceType === 'backlog') {
            // Move tasks within the same backlog
            const updatedBacklogs = [...backlogs];
            const task = updatedBacklogs[sourceBacklogIndex].tasks[sourceTaskIndex];
            updatedBacklogs[sourceBacklogIndex].tasks.splice(sourceTaskIndex, 1);
            updatedBacklogs[sourceBacklogIndex].tasks.splice(targetTaskIndex, 0, task);
            setBacklogs(updatedBacklogs);
        }
    };

    const handleDragOver = (e) => {
        e.preventDefault();
    };

    const handleToggleSubtaskInput = (taskIndex) => {
        if (showAddSubtaskInput === taskIndex) {
            setShowAddSubtaskInput(null);
        } else {
            setShowAddSubtaskInput(taskIndex);
            setTimeout(() => {
                subtaskInputRef.current.focus();
            }, 0);
        }
    };

    const handleBlurSubtaskInput = () => {
        setShowAddSubtaskInput(null);
    };

    const handleSprintExpand = (Index) => {
        setShowSprintExpand(Index);
        setSprintExpand(!Sprintexpand);
    };

    const handleTaskExpand = (Index) => {
        setShowTaskExpand(Index);
        setselectedTaskId(Index);
        setTaskExpand(!Taskexpand);
    };





    const handleDeleteTask = (sprintIndex, taskIndex) => {
        // Handle delete task functionality
        console.log(`Delete task in Sprint ${sprintIndex} - Task ${taskIndex}`);
    };

    const handleDeleteSprint = (sprintId) => {
        // Handle delete task functionality

        console.log(`Delete task in Sprint ${sprintId}`);
    };

    const handleStartTask = (sprintIndex, taskIndex) => {
        // Handle start task functionality
        console.log(`Start task in Sprint ${sprintIndex} - Task ${taskIndex}`);
    };

    const openDelConfirmPopup = (SprintId) => {
        setSelectedSprintId(SprintId);
        setIsOpenDelConfirm(true);
    };

    const closeDelConfirmPopup = () => {
        setSelectedSprintId(null);
        setIsOpenDelConfirm(false);
    };


    const handleEditTask = (sprintIndex, taskIndex) => {
        // Handle edit task functionality
        console.log(`Edit task in Sprint ${sprintIndex} - Task ${taskIndex}`);
    };

    const handleEditSprint = (sprintIndex) => {
        // Handle edit sprint functionality
        console.log(`Edit Sprint ${sprintIndex}`);
    };



    return (
        <div className="sprint-backlog">
            <Sidebar
                setUpView={setUpView}
                view={view}
            />
            <div className="backlog-panel">
                <h2>Backlogs</h2>
                <div className="backlog-table" onDrop={(e) => handleDrop(e, 'backlog')} onDragOver={handleDragOver}>
                    {backlogs.map((backlog, index) => (
                        <div
                            className="backlog-row draggable"
                            key={index}
                            draggable="true"
                            onDragStart={(e) => handleDragStart(e, backlog.title, 'backlog', null, null, index)}
                        >
                            {backlog.title}
                        </div>
                    ))}
                </div>
                <div className="add-backlog-row">
                    <input
                        type="text"
                        className="add-backlog-input"
                        placeholder="Add New issue"
                        value={newBacklog}
                        onChange={handleBacklogChange}
                        onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                                handleAddBacklog();
                                e.target.value = '';
                            }
                        }}
                    />
                    <button className="add-backlog-button" onClick={handleAddBacklog}>
                        +
                    </button>
                </div>
            </div>
            <div className='sprint-workspace'>
                <h2>Sprints</h2>
                <div className="sprint-tables">
                    {sprints.map((sprint, sprintIndex) => (
                        <div className="sprint-table" key={sprintIndex}>
                            <div
                                className={`sprint ${sprint.sprintId === selectedSprintId ? 'active' : 'deactive'}`}
                                onClick={() => handleStartSprint(sprint.sprintId)}
                                onDrop={(e) => handleDrop(e, 'sprint', sprintIndex, null)}
                                onDragOver={handleDragOver}
                                ref={sprintTableRef}
                            >
                                <div className="sprint-header" >
                                    <div
                                        onClick={(e) => handleSprintExpand(sprint.sprintId)}
                                        className={
                                            selectedSprintId === sprint.sprintId &&
                                                showExpandSprint === sprint.sprintId &&
                                                Sprintexpand
                                                ? 'arrow-clicked'
                                                : 'arrow'
                                        }
                                    >
                                        {selectedSprintId === sprint.sprintId &&
                                            showExpandSprint === sprint.sprintId &&
                                            Sprintexpand ? (
                                            <FaChevronDown />
                                        ) : (
                                            <FaChevronRight />
                                        )}
                                    </div>

                                    {sprint.name}
                                    <div className="sprint-icons">
                                        <FaEdit
                                            className="edit-button"
                                            onClick={() => handleEditSprint(sprintIndex, null)}
                                        />
                                        <FaTrashAlt
                                            className="delete-button"
                                            onClick={() => openDelConfirmPopup(sprint.sprintId)}
                                        />
                                        <FaPlay
                                            className="start-button"
                                            onClick={() => handleStartSprint(sprint.sprintId, null)}
                                        />
                                    </div>
                                </div>
                                {selectedSprintId === sprint.sprintId &&
                                    showExpandSprint === sprint.sprintId &&
                                    Sprintexpand && sprint.tasks.map((task, taskIndex) => (
                                        <ul className="task-list" key={taskIndex}>
                                            <li
                                                className="task"
                                                draggable="true"
                                                onDragStart={(e) =>
                                                    handleDragStart(e, task.title, 'sprint', sprintIndex, taskIndex)
                                                }
                                                onDrop={(e) =>
                                                    handleDrop(e, 'sprint', sprintIndex, taskIndex)
                                                }
                                                onDragOver={handleDragOver}
                                            >
                                                <div
                                                    onClick={(e) => handleTaskExpand(task.taskId)}
                                                    className="task-header"
                                                >
                                                    <div
                                                        className={
                                                            selectedSprintId === sprint.sprintId &&
                                                                showExpandTask === task.taskId &&
                                                                Taskexpand
                                                                ? 'arrow-clicked'
                                                                : 'arrow'
                                                        }
                                                    >
                                                        {selectedSprintId === sprint.sprintId &&
                                                            showExpandTask === task.taskId && selectedTaskId === task.taskId &&
                                                            Taskexpand ? (
                                                            <FaChevronDown />
                                                        ) : (
                                                            <FaChevronRight />
                                                        )}
                                                    </div>
                                                    {task.title}
                                                </div>

                                                {selectedSprintId === sprint.sprintId && showExpandTask === task.taskId && Taskexpand && (
                                                    <div className="content">
                                                        {task.tasks.length > 0 && (
                                                            <ul className="SetList">
                                                                {task.tasks.map((subtask, subtaskIndex) => (
                                                                    <li className="subtask" key={subtaskIndex}>
                                                                        {subtask.title}
                                                                    </li>
                                                                ))}
                                                            </ul>
                                                        )}
                                                        {showAddSubtaskInput === taskIndex ? (
                                                            <div className="add-subtask-row">
                                                                <input
                                                                    ref={subtaskInputRef}
                                                                    type="text"
                                                                    className="add-subtask-input"
                                                                    placeholder="New Subtask"
                                                                    onBlur={handleBlurSubtaskInput}
                                                                    onKeyDown={(e) => {
                                                                        if (e.key === 'Enter') {
                                                                            handleAddSubtaskToTask(e.target.value, sprintIndex, taskIndex);
                                                                            e.target.value = '';
                                                                        }
                                                                    }}
                                                                />
                                                            </div>
                                                        ) : (
                                                            <button
                                                                className="toggle-subtask-button"
                                                                onClick={() => handleToggleSubtaskInput(taskIndex)}
                                                            >
                                                                Add Subtask
                                                            </button>
                                                        )}
                                                    </div>
                                                )}
                                            </li>
                                        </ul>
                                    ))}
                                {selectedSprintId === sprint.sprintId && (
                                    <div className="add-task-row">
                                        {!showAddTaskInput ? (
                                            <button className="add-task-button" onClick={() => setShowAddTaskInput(true)}>
                                                Add issue
                                            </button>
                                        ) : (
                                            <div>
                                                <input
                                                    type="text"
                                                    className="add-task-input"
                                                    placeholder="Add New Issue"
                                                    onKeyDown={(e) => {
                                                        if (e.key === 'Enter') {
                                                            handleAddTaskToSprint(e.target.value, sprintIndex);
                                                            e.target.value = '';
                                                            setShowAddTaskInput(false);
                                                        }
                                                    }}
                                                />
                                                <button
                                                    className="add-task-button"
                                                    onClick={() => {
                                                        handleAddTaskToSprint(
                                                            document.querySelector('.add-task-input').value,
                                                            sprintIndex
                                                        );
                                                        document.querySelector('.add-task-input').value = '';
                                                        setShowAddTaskInput(false);
                                                    }}
                                                >
                                                    <FaCheck />
                                                </button>
                                            </div>
                                        )}
                                    </div>
                                )}
                            </div>
                        </div>
                    ))}
                    <div className="add-sprint-button" onClick={handleAddSprint}>
                        +
                    </div>
                </div>

                {
                    isOpenDelConfirm && (
                        <DeleteSprint
                            sprintId={selectedSprintId}
                            closePopup={closeDelConfirmPopup}
                        />
                    )
                }
            </div>
        </div>
    );
};

export default BacklogArea;